import React, { useEffect, useMemo, useRef, useState } from "react";

/* ============================================================================
   Reading App – RTL + Minutes-only + Books add/remove (TypeScript / TSX)
   - RTL: dir="rtl" lang="he"
   - Minutes only: אין "עמודים"
   - Books: הוספה, שיוך לילדים, ומחיקה גלובלית
   - LocalStorage Persistence + CSV (כולל mood)
   - Mood scale: 😊 (שמאל, מאוד שמח) ← סליידר → 😐 (ימין, פחות שמח)
   ========================================================================== */

type AgeBand = "7-9" | "10-12";

interface Reflection {
  qid: string;
  question: string;
  answer: string;
}
interface Session {
  id: string;
  childId: string;
  childName: string;
  date: string; // ISO
  minutes: number;
  bookId: string;
  bookTitle?: string;
  note?: string;
  mood?: string; // emoji
  reflections: Reflection[];
}
interface Child {
  id: string;
  name: string;
  age: number;
  goalMinutes: number;
  color: string; // tailwind bg-...
  bookIds?: string[];
}
interface Book {
  id: string;
  title: string;
  author: string;
}
interface SessionState {
  stage: "setup" | "running" | "reflect";
  bookId: string;
  targetMinutes: number;
  note: string;
  elapsedSec?: number;
}

const LS = {
  children: "rb_children_v1",
  books: "rb_books_v1",
  sessions: "rb_sessions_v1",
} as const;

const AGE_BANDS: Record<AgeBand, string[]> = {
  "7-9": [
    "מי הדמות שהכי אהבת ולמה?",
    "מה קרה בהתחלה, באמצע ובסוף?",
    "מילה חדשה שלמדתי היום היא…",
    "מה הפתיע אותך בסיפור?",
    "אם היית יכול/ה לשנות דבר אחד – מה היית משנה?",
    "לאיזה דמות היית רוצה לכתוב מכתב? מה היית כותב/ת?",
    "מה הרגישה הדמות ברגע חשוב?",
    "בחר/י אימוג׳י שמתאר את הקריאה היום והסבר/י למה",
    "מה למדת על המקום או הזמן שבו מתרחש הסיפור?",
    "למה הדמות עשתה פעולה מסוימת? הסבר/י"
  ],
  "10-12": [
    "מה המטרה של הדמות הראשית וכמה הצליחה?",
    "איזה רמזים מוקדמים הופיעו לפני האירוע המרכזי?",
    "מה הקונפליקט המרכזי – פנימי או חיצוני?",
    "ציין/י ציטוט משמעותי והסבר/י למה בחרת בו",
    "איך התקופה/המקום משפיעים על הבחירות של הדמות?",
    "תקציר ב-3 משפטים כולל מסר אפשרי",
    "מילה/ביטוי מאתגר: הגדרה במילים שלך + דוגמה",
    "אם היית מראיין/ת את המחבר – איזו שאלה היית שואל/ת ולמה?",
    "מה ההבדל בין נקודת המבט שלך ושל הדמות?",
    "נבא/י: מה יקרה בפרק הבא ולמה?"
  ]
};

const STARTER_CHILDREN: Child[] = [
  { id: "amit", name: "עמית", age: 12, goalMinutes: 120, color: "bg-blue-700", bookIds: ["b1", "b2"] },
  { id: "joya", name: "ג׳ויה", age: 8, goalMinutes: 90, color: "bg-green-700", bookIds: ["b3"] }
];

const STARTER_BOOKS: Book[] = [
  { id: "b1", title: "הארי פוטר ואבן החכמים", author: "J.K. Rowling" },
  { id: "b2", title: "יומנו של חנון", author: "Jeff Kinney" },
  { id: "b3", title: "איה פלוטו", author: "לאה גולדברג" }
];

const MOOD_MAP = { 1: "😊", 2: "🙂", 3: "😐" } as const;

const ageBand = (age: number): AgeBand => (age <= 9 ? "7-9" : "10-12");
const rid = (): string =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? (crypto as Crypto).randomUUID()
    : "id_" + Math.random().toString(36).slice(2);

const formatTime = (sec: number) =>
  `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;

function pickTwoUnique(arr: string[]) {
  if (arr.length <= 2) return arr.map((t, i) => ({ id: String(i), text: t }));
  let a = Math.floor(Math.random() * arr.length);
  let b = Math.floor(Math.random() * arr.length);
  while (b === a) b = Math.floor(Math.random() * arr.length);
  return [
    { id: String(a), text: arr[a] },
    { id: String(b), text: arr[b] }
  ];
}

function downloadCSV(filename: string, rows: (string | number)[][]) {
  const cell = (v: string | number) => {
    const s = String(v ?? "");
    const esc = s.replaceAll('"', '""');
    return esc.includes(",") || esc.includes("\n") ? `"${esc}"` : esc;
  };
  const csv = rows.map((r) => r.map(cell).join(",")).join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ============================== App =========================================
export default function App() {
  const [children, setChildren] = useState<Child[]>(() => {
    try { const raw = localStorage.getItem(LS.children); return raw ? JSON.parse(raw) : STARTER_CHILDREN; }
    catch { return STARTER_CHILDREN; }
  });
  const [books, setBooks] = useState<Book[]>(() => {
    try { const raw = localStorage.getItem(LS.books); return raw ? JSON.parse(raw) : STARTER_BOOKS; }
    catch { return STARTER_BOOKS; }
  });
  const [sessions, setSessions] = useState<Session[]>(() => {
    try { const raw = localStorage.getItem(LS.sessions); return raw ? JSON.parse(raw) : []; }
    catch { return []; }
  });

  useEffect(() => localStorage.setItem(LS.children, JSON.stringify(children)), [children]);
  useEffect(() => localStorage.setItem(LS.books, JSON.stringify(books)), [books]);
  useEffect(() => localStorage.setItem(LS.sessions, JSON.stringify(sessions)), [sessions]);

  const [view, setView] = useState<"kids" | "parent">("kids");
  const [activeChildId, setActiveChildId] = useState<string | null>(null);
  const [sessionState, setSessionState] = useState<SessionState | null>(null);

  const activeChild = children.find((c) => c.id === activeChildId) || null;

  const startForChild = (childId: string) => {
    const child = children.find((c) => c.id === childId);
    const childBooks = books.filter((b) => (child?.bookIds || []).includes(b.id));
    const firstBook = (childBooks[0] || books[0] || { id: "" }).id;
    setActiveChildId(childId);
    setSessionState({
      stage: "setup",
      bookId: firstBook,
      targetMinutes: 20,
      note: ""
    });
  };

  const endAndSave = async (payload) => {
    try {
      // שולח לשרת – זה החלק שמסנכרן בין כל המכשירים
      await fetch('/.netlify/functions/sessions-post', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
  
      // אופציונלי: לעדכן מיד את המסך מקומית
      setSessions((prev) => [payload, ...prev]);
    } catch (e) {
      console.error('Save failed', e);
      alert('שמירה לשרת נכשלה. נסה שוב.');
    }
  
    setSessionState(null);
    setActiveChildId(null);
    setView('parent');
  };  

  const onDeleteBookGlobal = (bookId: string) => {
    setBooks((prev) => prev.filter((b) => b.id !== bookId));
    setChildren((prev) =>
      prev.map((ch) => ({
        ...ch,
        bookIds: (ch.bookIds || []).filter((id) => id !== bookId)
      }))
    );
  };
// טוען סשנים מהשרת (Netlify Function → Neon DB)
const refreshSessions = async () => {
  try {
    const res = await fetch('/.netlify/functions/sessions-get');
    const data = await res.json();
    setSessions(data);
  } catch (e) {
    console.error('Fetch failed', e);
  }
};
useEffect(() => {
  if (view === 'parent') {
    refreshSessions();
  }
}, [view]);
  return (
    <div dir="rtl" lang="he" className="min-h-screen w-full bg-slate-50 text-slate-900 text-right">
      <Header view={view} onSwitch={setView} />
      <main className="mx-auto max-w-6xl p-4 md:p-8">
        {view === "kids" ? (
          <KidsView
            childrenList={children}
            books={books}
            onStart={startForChild}
            activeChild={activeChild}
            sessionState={sessionState}
            setSessionState={setSessionState}
            onSave={endAndSave}
          />
        ) : (
          <ParentDashboard
            sessions={sessions}
            childrenList={children}
            setChildren={setChildren}
            books={books}
            setBooks={setBooks}
            onDeleteBook={onDeleteBookGlobal}
            onExportCSV={() => exportCSV(sessions, children, books)}
          />
        )}
      </main>
      <Footer />
    </div>
  );
}

// ============================ Header ========================================
function Header({ view, onSwitch }: { view: "kids" | "parent"; onSwitch: (v: "kids" | "parent") => void }) {
  return (
    <div className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between p-4">
        <div className="flex items-center gap-2">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-2xl bg-indigo-600 text-white">📚</span>
          <div className="font-semibold">חבר קריאה</div>
        </div>
        <div className="flex gap-2 rounded-xl bg-slate-100 p-1">
          <button onClick={() => onSwitch("kids")} className={"rounded-lg px-3 py-1 text-sm " + (view === "kids" ? "bg-white shadow" : "text-slate-600")}>מסך ילדים</button>
          <button onClick={() => onSwitch("parent")} className={"rounded-lg px-3 py-1 text-sm " + (view === "parent" ? "bg-white shadow" : "text-slate-600")}>דשבורד הורה</button>
        </div>
      </div>
    </div>
  );
}

// ============================ Kids flow =====================================
function KidsView(props: {
  childrenList: Child[];
  books: Book[];
  onStart: (childId: string) => void;
  activeChild: Child | null;
  sessionState: SessionState | null;
  setSessionState: (s: SessionState) => void;
  onSave: (s: Session) => void;
}) {
  const { childrenList, books, onStart, activeChild, sessionState, setSessionState, onSave } = props;

  return (
    <div>
      {!activeChild && (
        <>
          <h2 className="mb-4 text-xl font-semibold">בחר/י פרופיל</h2>
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
            {childrenList.map((c) => (
              <button key={c.id} onClick={() => onStart(c.id)} className="rounded-2xl border bg-white p-4 shadow-sm transition hover:shadow-md text-right">
                <div className="flex items-center justify-between">
                  <div className="text-4xl">{avatarFromAge(c.age)}</div>
                  <span className={`rounded-xl px-2 py-1 text-xs ${c.color} text-white`}>גיל {c.age}</span>
                </div>
                <div className="mt-2 text-lg font-semibold">{c.name}</div>
                <div className="text-sm text-slate-500">יעד שבועי: {c.goalMinutes} ד׳</div>
              </button>
            ))}
          </div>
        </>
      )}

      {activeChild && sessionState?.stage === "setup" && (
        <SessionSetup child={activeChild} state={sessionState} setState={setSessionState} books={books} />
      )}

      {activeChild && sessionState?.stage === "running" && (
        <SessionRun child={activeChild} state={sessionState} setState={setSessionState} />
      )}

      {activeChild && sessionState?.stage === "reflect" && (
        <SessionReflect child={activeChild} state={sessionState} onSave={onSave} books={books} />
      )}
    </div>
  );
}

function SessionSetup({ child, state, setState, books }: { child: Child; state: SessionState; setState: (s: SessionState) => void; books: Book[]; }) {
  const childBookIds = new Set(child.bookIds || []);
  const sortedBooks = [...books].sort((a, b) => (childBookIds.has(b.id) ? 1 : 0) - (childBookIds.has(a.id) ? 1 : 0));

  const onChangeTarget = (e: React.ChangeEvent<HTMLInputElement>) => setState({ ...state, targetMinutes: Number(e.target.value) || 0 });
  const onChangeNote = (e: React.ChangeEvent<HTMLTextAreaElement>) => setState({ ...state, note: e.target.value });
  const onChangeBook = (e: React.ChangeEvent<HTMLSelectElement>) => setState({ ...state, bookId: e.target.value });

  return (
    <div className="mx-auto max-w-2xl">
      <h2 className="mb-2 text-xl font-semibold">שלום {child.name}! בוא/י נתכונן לקריאה</h2>
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <div className="grid gap-4 md:grid-cols-2">
          <label className="grid gap-1 text-sm">
            <span>בחר/י ספר</span>
            <select className="rounded-xl border bg-white p-2" value={state.bookId} onChange={onChangeBook}>
              {sortedBooks.map((b) => (
                <option key={b.id} value={b.id}>{b.title} — {b.author}</option>
              ))}
            </select>
          </label>

          <label className="grid gap-1 text-sm">
            <span>יעד דקות</span>
            <input type="number" min={5} max={180} className="rounded-xl border bg-white p-2" value={state.targetMinutes} onChange={onChangeTarget} />
          </label>

          <label className="grid gap-1 text-sm md:col-span-2">
            <span>הערה (אופציונלי)</span>
            <textarea className="min-h-[80px] rounded-xl border bg-white p-2" placeholder="משהו שתרצה לזכור…" value={state.note} onChange={onChangeNote} />
          </label>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-600"><span className="text-2xl">⏱️</span> מוכן/ה ל{state.targetMinutes} דקות?</div>
          <button onClick={() => setState({ ...state, stage: "running" })} className="rounded-xl bg-indigo-600 px-4 py-2 text-white shadow hover:bg-indigo-700">התחל/י קריאה</button>
        </div>
      </div>
    </div>
  );
}

function SessionRun({ child, state, setState }: { child: Child; state: SessionState; setState: (s: SessionState) => void; }) {
  const [seconds, setSeconds] = useState<number>(0);
  const [running, setRunning] = useState<boolean>(true);
  const targetSec = (state.targetMinutes || 0) * 60;
  const ref = useRef<number | null>(null);

  useEffect(() => {
    if (running) ref.current = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => { if (ref.current) window.clearInterval(ref.current); };
  }, [running]);

  const pct = Math.min(100, Math.round((seconds / Math.max(targetSec, 1)) * 100));

  return (
    <div className="mx-auto max-w-2xl">
      <h2 className="mb-2 text-xl font-semibold">זמן לקרוא, {child.name}!</h2>
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <div className="mb-3 text-sm text-slate-600">יעד: {state.targetMinutes} ד׳ • עבר: {formatTime(seconds)}</div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-slate-200">
          <div className="h-full bg-indigo-600 transition-all" style={{ width: pct + "%" }} />
        </div>
        <div className="mt-4 flex gap-2">
          <button className="rounded-xl border px-3 py-2" onClick={() => setRunning((r) => !r)}>{running ? "הפסק/י" : "המשכ/י"}</button>
          <button className="rounded-xl bg-indigo-600 px-3 py-2 text-white" onClick={() => setState({ ...state, stage: "reflect", elapsedSec: seconds })}>סיום</button>
        </div>
      </div>
    </div>
  );
}

function SessionReflect({ child, state, onSave, books }: { child: Child; state: SessionState; onSave: (s: Session) => void; books: Book[]; }) {
  const band = ageBand(child.age);
  const questions = AGE_BANDS[band];
  const [q1, q2] = useMemo(() => pickTwoUnique(questions), [questions]);

  // Mood scale — 1: 😊 (שמאל), 3: 😐 (ימין)
  const [moodLevel, setMoodLevel] = useState<number>(2); // 1=😊, 2=🙂, 3=😐
  const [ans, setAns] = useState<Record<string, string>>({ [q1.id]: "", [q2.id]: "" });

  const handleSave = () => {
    const minutes = Math.max(1, Math.round((state.elapsedSec || 0) / 60));
    onSave({
      id: rid(),
      childId: child.id,
      childName: child.name,
      date: new Date().toISOString(),
      minutes,
      bookId: state.bookId,
      bookTitle: books.find((b) => b.id === state.bookId)?.title,
      note: state.note,
      mood: MOOD_MAP[moodLevel as 1 | 2 | 3],
      reflections: [
        { qid: q1.id, question: q1.text, answer: ans[q1.id] },
        { qid: q2.id, question: q2.text, answer: ans[q2.id] }
      ]
    });
  };

  const onChangeSlider = (e: React.ChangeEvent<HTMLInputElement>) => setMoodLevel(Number(e.target.value));
  const onChangeAns1 = (v: string) => setAns((p) => ({ ...p, [q1.id]: v }));
  const onChangeAns2 = (v: string) => setAns((p) => ({ ...p, [q2.id]: v }));

  return (
    <div className="mx-auto max-w-2xl">
      <h2 className="mb-2 text-xl font-semibold">סיום סשן – שאלות קצרות</h2>
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        {/* Mood scale row: left 😊 — slider — right 😐 */}
        <div className="mb-3 text-sm text-slate-600" dir="ltr">
          <div className="flex items-center gap-3">
            <span aria-hidden>😊</span>
            <input type="range" min={1} max={3} step={1} value={moodLevel} onChange={onChangeSlider} aria-label="Mood scale" className="flex-1 accent-indigo-600" />
            <span aria-hidden>😐</span>
          </div>
        </div>

        <QuestionCard text={q1.text} value={ans[q1.id]} onChange={onChangeAns1} />
        <QuestionCard text={q2.text} value={ans[q2.id]} onChange={onChangeAns2} />

        <div className="mt-4 flex justify-end gap-2">
          <button className="rounded-xl border px-4 py-2" onClick={handleSave}>שמור/י ליומן</button>
        </div>
      </div>
    </div>
  );
}

function QuestionCard({ text, value, onChange }: { text: string; value: string; onChange: (v: string) => void; }) {
  const onInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => onChange(e.target.value);
  return (
    <div className="mt-3 rounded-xl border p-3">
      <div className="text-sm font-medium">{text}</div>
      <textarea value={value} onChange={onInput} className="mt-2 w-full rounded-lg border p-2" placeholder="התשובה שלי…" />
    </div>
  );
}

// ============================ Parent Dashboard ==============================
function ParentDashboard(props: {
  sessions: Session[];
  childrenList: Child[];
  setChildren: React.Dispatch<React.SetStateAction<Child[]>>;
  books: Book[];
  setBooks: React.Dispatch<React.SetStateAction<Book[]>>;
  onDeleteBook: (bookId: string) => void;
  onExportCSV: () => void;
}) {
  const { sessions, childrenList, setChildren, books, setBooks, onDeleteBook, onExportCSV } = props;

  const grouped = useMemo(() => {
    const byChild: Record<string, Session[]> = Object.fromEntries(childrenList.map((c) => [c.id, []]));
    sessions.forEach((s) => byChild[s.childId]?.push(s));
    return byChild;
  }, [sessions, childrenList]);

  const [newBook, setNewBook] = useState<{ title: string; author: string }>({ title: "", author: "" });

  const addBook = () => {
    if (!newBook.title.trim()) return;
    const id = "b_" + Math.random().toString(36).slice(2, 9);
    const book: Book = { id, title: newBook.title.trim(), author: newBook.author.trim() };
    setBooks((prev) => [book, ...prev]);
    setNewBook({ title: "", author: "" });
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-xl font-semibold">דשבורד הורה</h2>
        <button onClick={onExportCSV} className="rounded-xl border px-3 py-2 text-sm">ייצוא CSV</button>
      </div>

      {/* Books manager (global) */}
      <div className="mb-6 rounded-2xl border bg-white p-4 shadow-sm">
        <div className="mb-2 font-medium">מאגר ספרים</div>
        {books.length === 0 ? (
          <div className="text-sm text-slate-500">אין ספרים במאגר.</div>
        ) : (
          <div className="mb-2 flex flex-wrap gap-2">
            {books.map((b) => (
              <span key={b.id} className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs">
                <span>{b.title}</span>
                <button title="מחק ספר" className="rounded bg-red-50 px-2 py-0.5 text-red-700" onClick={() => onDeleteBook(b.id)}>מחק</button>
              </span>
            ))}
          </div>
        )}
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <div className="grid gap-1">
            <label className="text-xs text-slate-500">כותרת</label>
            <input className="rounded-lg border p-1" value={newBook.title} onChange={(e) => setNewBook((p) => ({ ...p, title: e.target.value }))} />
          </div>
          <div className="grid gap-1">
            <label className="text-xs text-slate-500">מחבר/ת</label>
            <input className="rounded-lg border p-1" value={newBook.author} onChange={(e) => setNewBook((p) => ({ ...p, author: e.target.value }))} />
          </div>
          <button className="rounded-lg border px-3 py-2" onClick={addBook}>הוסף ספר</button>
        </div>
      </div>

      {/* Child cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {childrenList.map((c) => (
          <ChildCard
            key={c.id}
            child={c}
            sessions={grouped[c.id] || []}
            onUpdate={(patch) => setChildren((prev) => prev.map((x) => (x.id === c.id ? { ...x, ...patch } : x)))}
            books={books}
          />
        ))}
      </div>

      <div className="mt-6 rounded-2xl border bg-white p-4 shadow-sm">
        <h3 className="mb-2 text-lg font-semibold">יומן אחרון</h3>
        <SessionTable sessions={sessions.slice(0, 12)} childrenList={childrenList} books={books} />
      </div>
    </div>
  );
}

function ChildCard({ child, sessions, onUpdate, books }: { child: Child; sessions: Session[]; onUpdate: (patch: Partial<Child>) => void; books: Book[]; }) {
  const totalMin = sessions.reduce((sum, s) => sum + (s.minutes || 0), 0);
  const pct = Math.min(100, Math.round((totalMin / Math.max(child.goalMinutes || 1, 1)) * 100));
  const lastAnswers = sessions.flatMap((s) => s.reflections || []).slice(0, 2);
  const [goal, setGoal] = useState<number>(child.goalMinutes || 60);

  useEffect(() => setGoal(child.goalMinutes || 60), [child.goalMinutes]);

  const childBooks = books.filter((b) => (child.bookIds || []).includes(b.id));

  const toggleAssign = (bookId: string) => {
    const setIds = new Set(child.bookIds || []);
    if (setIds.has(bookId)) setIds.delete(bookId);
    else setIds.add(bookId);
    onUpdate({ bookIds: Array.from(setIds) });
  };

  const onGoalChange = (e: React.ChangeEvent<HTMLInputElement>) => setGoal(Number(e.target.value));

  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-3xl">{avatarFromAge(child.age)}</div>
          <div>
            <div className="text-lg font-semibold">{child.name}</div>
            <div className="text-sm text-slate-500">גיל {child.age}</div>
          </div>
        </div>
        <span className="rounded-xl bg-slate-100 px-2 py-1 text-xs">{sessions.length} סשנים</span>
      </div>

      <div className="mb-2 text-sm text-slate-600">התקדמות שבועית</div>
      <div className="h-3 w-full overflow-hidden rounded-full bg-slate-200">
        <div className="h-full bg-emerald-500 transition-all" style={{ width: pct + "%" }} />
      </div>
      <div className="mt-1 text-sm text-slate-600">סה״כ {totalMin} ד׳ ({pct}%) מתוך יעד {child.goalMinutes} ד׳</div>

      <div className="mt-3 flex items-center gap-2 text-sm">
        <span className="text-slate-600">עדכון יעד שבועי:</span>
        <input type="number" min={15} className="w-24 rounded-lg border p-1" value={goal} onChange={onGoalChange} />
        <button className="rounded-lg border px-2 py-1" onClick={() => onUpdate({ goalMinutes: Number(goal) || 60 })}>שמור</button>
      </div>

      {lastAnswers.length > 0 && (
        <div className="mt-3 text-sm">
          <div className="mb-1 font-medium">היילייטים מרפלקציה</div>
          {lastAnswers.map((r, i) => (
            <div key={i} className="mb-1 rounded-lg bg-slate-50 p-2">
              <span className="text-slate-500">שאלה:</span> {r.question}
              <br />
              <span className="text-slate-500">תשובה:</span> {r.answer || "—"}
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 rounded-xl border p-3">
        <div className="mb-2 text-sm font-medium">ספרים משויכים</div>
        {childBooks.length === 0 && <div className="text-sm text-slate-500">אין ספרים משויכים עדיין.</div>}

        <div className="mb-2 flex flex-wrap gap-2">
          {books.map((b) => (
            <label key={b.id} className="inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-xs">
              <input type="checkbox" checked={(child.bookIds || []).includes(b.id)} onChange={() => toggleAssign(b.id)} />
              <span>{b.title}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}

function SessionTable({ sessions, childrenList, books }: { sessions: Session[]; childrenList: Child[]; books: Book[]; }) {
  const childName = (id: string) => childrenList.find((c) => c.id === id)?.name || id;
  const bookTitle = (id: string) => books.find((b) => b.id === id)?.title || id;
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-right text-sm">
        <thead>
          <tr className="bg-slate-100 text-slate-700">
            <th className="p-2">תאריך</th>
            <th className="p-2">ילד/ה</th>
            <th className="p-2">ספר</th>
            <th className="p-2">דקות</th>
            <th className="p-2">מצב רוח</th>
          </tr>
        </thead>
        <tbody>
          {sessions.length === 0 && (
            <tr><td colSpan={5} className="p-3 text-center text-slate-500">אין עדיין נתונים. נסו להשלים סשן אחד.</td></tr>
          )}
          {sessions.map((s) => (
            <tr key={s.id} className="border-b">
              <td className="p-2">{new Date(s.date).toLocaleString("he-IL", { dateStyle: "short", timeStyle: "short" })}</td>
              <td className="p-2">{childName(s.childId)}</td>
              <td className="p-2">{s.bookTitle || bookTitle(s.bookId)}</td>
              <td className="p-2">{s.minutes}</td>
              <td className="p-2">{s.mood || ""}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================== Footer ======================================
function Footer() {
  return <div className="mt-8 border-t py-6 text-center text-xs text-slate-500">MVP Demo • נתונים נשמרים ב-LocalStorage בדפדפן • אין שרת</div>;
}

function avatarFromAge(age: number) {
  if (age <= 8) return "🦊";
  if (age <= 10) return "🐼";
  return "🦁";
}

// CSV (minutes + mood)
function exportCSV(sessions: Session[], children: Child[], books: Book[]) {
  const childName = (id: string) => children.find((c) => c.id === id)?.name || id;
  const bookTitle = (id: string) => books.find((b) => b.id === id)?.title || id;
  const rows: (string | number)[][] = [
    ["תאריך", "ילד/ה", "ספר", "דקות", "מצב רוח", "שאלה 1", "תשובה 1", "שאלה 2", "תשובה 2", "הערה"],
    ...sessions.map((s) => [
      new Date(s.date).toLocaleString("he-IL"),
      childName(s.childId),
      s.bookTitle || bookTitle(s.bookId),
      s.minutes,
      s.mood || "",
      s.reflections?.[0]?.question || "",
      s.reflections?.[0]?.answer || "",
      s.reflections?.[1]?.question || "",
      s.reflections?.[1]?.answer || "",
      s.note || ""
    ])
  ];
  downloadCSV("reading_log.csv", rows);
}